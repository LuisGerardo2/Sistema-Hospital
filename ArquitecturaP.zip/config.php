<?php
$db = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'db' => 'hospital' //Cambiar al nombre de tu base de datos
];
?>